Usage scenarios
======================

In this section we present typical usage scenarios. They could help you figure out what WorldEngine can be used for.