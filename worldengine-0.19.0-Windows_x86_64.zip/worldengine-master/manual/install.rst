Install
======================

WorldEngine will not be any good for you if you do not manage to install it first. Let's see how to do that.