GUI
======================

Ok, you prefer graphical interfaces: we got you covered.